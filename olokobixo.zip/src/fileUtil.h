#ifndef _FILE_UTIL_H
#define _FILE_UTIL_H

#include <stdio.h>
#include <stdlib.h>

FILE *criaArquivoEscrita(char *);
FILE *abreArquivo(char *);
int raizArvoreB();
int quantidadePaginasArvoreB();
int atualizaRaizArvoreB(int);
int atualizaQuantidadePaginasArvoreB(int);
int leiaIntDasChaves(FILE *, int *);
int byteOffsetApartirDoRRN(int);

int leiaIntDasChaves(FILE *file, int *num) {
    return fscanf(file, "%d|", num);
}

int atualizaRaizArvoreB(int valor) {
    FILE *arvore = abreArquivo(ARQUIVO_DADOS);
    fread(&valor, sizeof(int), 1, arvore);
    fclose(arvore);
    return valor;
}

int atualizaQuantidadePaginasArvoreB(int valor) {
    FILE *arvore = abreArquivo(ARQUIVO_DADOS);
    fseek(arvore, sizeof(int), SEEK_SET);
    fread(&valor, sizeof(int), 1, arvore);
    fclose(arvore);
    return valor;
}

int raizArvoreB() {
    int raiz;
    FILE *arvore = abreArquivo(ARQUIVO_DADOS);
    fread(&raiz, sizeof(int), 1, arvore);
    fclose(arvore);
    return raiz;
}

int quantidadePaginasArvoreB() {
    int quantidade;
    FILE *arvore = abreArquivo(ARQUIVO_DADOS);
    fseek(arvore, sizeof(int), SEEK_SET);
    fread(&quantidade, sizeof(int), 1, arvore);
    fclose(arvore);
    return quantidade;
}

FILE *criaArquivoEscrita(char *nomeArquivo) {
    /*
        Ambos r+e w+podem ler e gravar em um arquivo. No entanto, r+ não exclui o conteúdo do
        arquivo e não cria um novo arquivo se tal arquivo não existir, enquanto w+ exclui o
        conteúdo do arquivo e o cria se ele não existir.

        URL: https://stackoverflow.com/questions/21113919/difference-between-r-and-w-in-fopen
    */
    FILE *arquivo = fopen(nomeArquivo, "w");

    if (arquivo == NULL) {
        fprintf(stderr, "Nao foi possivel abrir o aquivo %s\n", nomeArquivo);
        exit(1);
    }

    return arquivo;
}

FILE *abreArquivo(char *nomeArquivo) {
    /*
        Ambos r+e w+podem ler e gravar em um arquivo. No entanto, r+ não exclui o conteúdo do
        arquivo e não cria um novo arquivo se tal arquivo não existir, enquanto w+ exclui o
        conteúdo do arquivo e o cria se ele não existir.

        URL: https://stackoverflow.com/questions/21113919/difference-between-r-and-w-in-fopen
    */
    FILE *arquivo = fopen(nomeArquivo, "r+");

    if (arquivo == NULL) {
        fprintf(stderr, "Nao foi possivel abrir o aquivo %s\n", nomeArquivo);
        exit(1);
    }

    return arquivo;
}

int byteOffsetApartirDoRRN(int rrn) {
    return 2 * sizeof(int) + (rrn * sizeof(Pagina));
}

#endif